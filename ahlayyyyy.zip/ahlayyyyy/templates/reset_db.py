import os
from app import app, db, Player

def reset_database():
    # Delete existing database
    if os.path.exists("database.db"):
        os.remove("database.db")
        print("Old database removed.")

    # Create new database
    with app.app_context():
        db.create_all()
        print("New database created.")

        # Add players
        players = [
            # ... (all player data from previous app.py) ...
        ]

        try:
            for player in players:
                db.session.add(player)
            db.session.commit()
            print("Players added successfully!")
        except Exception as e:
            db.session.rollback()
            print(f"Error adding players: {e}")

if __name__ == "__main__":
    reset_database()