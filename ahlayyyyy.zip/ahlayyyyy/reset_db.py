import os
from app import app, db, Player

def reset_database():
    with app.app_context():
        # Drop all tables and recreate them
        db.drop_all()
        db.create_all()
        print("Database reset successfully.")

        # Create players list
        players = [
            # Goalkeepers
            Player(name='Mohamed El Shenawy', position='Goalkeeper', number=1, image_url='/static/images/elshenawy.jpg'),
            Player(name='Mostafa Shobeir', position='Goalkeeper', number=31, image_url='/static/images/shobeir.jpg'),
            Player(name='Hamza Alaa', position='Goalkeeper', number=33, image_url='/static/images/hamza.jpg'),
            
            # Defenders
            Player(name='Yousef Ayman', position='Center Back', number=4, image_url='/static/images/ayman.jpg'),
            Player(name='Rami Rabia', position='Center Back', number=5, image_url='/static/images/rabia.jpg'),
            Player(name='Yasser Ibrahim', position='Center Back', number=6, image_url='/static/images/yasser.jpg'),
            Player(name='Ali Maaloul', position='Left Back', number=21, image_url='/static/images/maaloul.jpg'),
            Player(name='Akram Tawfik', position='Right Back', number=8, image_url='/static/images/tawfik.jpg'),
            Player(name='Karim Fouad', position='Right Back', number=28, image_url='/static/images/fouad.jpg'),
            Player(name='Mohammed Hany', position='Right Back', number=30, image_url='/static/images/hany.jpg'),
            
            # Midfielders
            Player(name='Marwan Atia', position='Attacking Midfielder', number=13, image_url='/static/images/marwan.jpg'),
            Player(name='Emam Ashour', position=' Midfielder', number=22, image_url='/static/images/ashour.jpg'),
            Player(name='Amr El Solia', position='Midfielder', number=17, image_url='/static/images/elsolia.jpg'),
            Player(name='Mohamed Magdy Afsha', position='Attacking Midfielder', number=19, image_url='/static/images/afsha.jpg'),
            Player(name='Ahmed Nabil Koka', position='Midfielder', number=36, image_url='/static/images/koka.jpg'),
            
            # Forwards/Wingers
            Player(name='Hussein El Shahat', position='Right_forward', number=14, image_url='/static/images/elshahat.jpg'),
            Player(name='Mahmoud Kahraba', position='Left_Forward', number=7, image_url='/static/images/kahraba.jpg'),
            Player(name='Percy Tau', position='Right_Forward', number=10, image_url='/static/images/tau.jpg'),
            Player(name='Taher Mohamed', position='left_forward', number=29, image_url='/static/images/taher.jpg'),
            Player(name='Wessam Abu Ali', position='Center_Forward', number=9, image_url='/static/images/wessam.jpg'),
        ] 
        try:
            # Add all players to the database
            for player in players:
                db.session.add(player)
            db.session.commit()
            print(f"Successfully added {len(players)} players to the database.")
            
            # Verify the players were added
            added_players = Player.query.all()
            print(f"\nVerifying players in database: {len(added_players)} found")
            for player in added_players:
                print(f"- {player.name} ({player.position}) #{player.number}")
                
        except Exception as e:
            db.session.rollback()
            print(f"Error adding players: {e}")

if __name__ == "__main__":
    # Delete existing database
    if os.path.exists("database.db"):
        os.remove("database.db")
        print("Old database removed.")
    
    reset_database()


