from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
from functools import wraps
import re

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

class Player(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    position = db.Column(db.String(50))
    number = db.Column(db.Integer)
    image_url = db.Column(db.String(200))

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login first', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Validation functions
def validate_password(password):
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    if not re.search("[a-z]", password):
        return False, "Password must contain at least one lowercase letter"
    if not re.search("[A-Z]", password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search("[0-9]", password):
        return False, "Password must contain at least one number"
    return True, ""

def validate_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, email):
        return False
    return True

# Routes
@app.route('/')
@login_required
def home():
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        confirm = request.form['confirm']

        # Check if passwords match
        if password != confirm:
            return render_template('signup.html', error="Passwords do not match")

        # Validation checks
        if User.query.filter_by(username=username).first():
            return render_template('signup.html', error="Username already exists")

        if User.query.filter_by(email=email).first():
            return render_template('signup.html', error="Email already registered")

        if not validate_email(email):
            return render_template('signup.html', error="Invalid email format")

        is_valid_password, password_message = validate_password(password)
        if not is_valid_password:
            return render_template('signup.html', error=password_message)

        hashed_password = generate_password_hash(password)
        new_user = User(username=username, password=hashed_password, email=email)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            return render_template('signup.html', error="An error occurred. Please try again.")

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            flash('Welcome back, {}!'.format(username), 'success')
            return redirect(url_for('home'))
        
        flash('Invalid username or password', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    flash('You have been logged out successfully', 'success')
    return redirect(url_for('login'))

@app.route('/players')
def players():
    positions = [
        'Goalkeeper',
        'Center Back',
        'Left Back',
        'Right Back',
        'Midfielder',
        'Attacking Midfielder',
        'Left_Forward',
        'Right_Forward',
        'Center_Forward'
    ]
    
    selected_position = request.args.get('position', 'all')
    
    if selected_position == 'all':
        players = Player.query.all()
    else:
        players = Player.query.filter_by(position=selected_position).all()
    
    return render_template('players.html', players=players, positions=positions, selected_position=selected_position)

@app.route('/achievements')
@login_required
def achievements():
    return render_template('achievements.html')

@app.route('/history')
@login_required
def history():
    return render_template('history.html')

# Initialize database with sample data
def init_db():
    with app.app_context():
        db.create_all()
        
        # Only add sample data if the Players table is empty
        if not Player.query.first():
            sample_players = [
                Player(
                    name='Mohamed El Shenawy',
                    position='Goalkeeper',
                    number=1,
                    image_url='/static/images/elshenawy.jpg'
                ),
                 Player(
                    name='Hamza Alaa',
                    position='Goalkeeper',
                    number=33,
                    image_url='/static/images/hamza.jpg'
                ),
                Player(
                    name='Ali Maaloul',
                    position='Left Back',
                    number=21,
                    image_url='/static/images/maaloul.jpg'
                ),
                Player(
                    name='Hussein El Shahat',
                    position='Winger',
                    number=14,
                    image_url='/static/images/elshahat.jpg'
                ),
                Player(
                    name='Percy Tau',
                    position='Forward',
                    number=22,
                    image_url='/static/images/tau.jpg'
                ),
                Player(
                    name='Kahraba',
                    position='Forward',
                    number=7,
                    image_url='/static/images/kahraba.jpg'
                ),
                Player(
                    name='Akram Tawfik',
                    position='Right Back',
                    number=12,
                    image_url='/static/images/tawfik.jpg'
                ),
                Player(
                    name='Amr El Solia',
                    position='Midfielder',
                    number=8,
                    image_url='/static/images/elsolia.jpg'
                ),
                Player(
                    name='Yousef Ayman',
                    position='Center Back',
                    number=4,
                    image_url='/static/images/ayman.jpg'
                ),
                Player(
                    name='Mahmoud Kahraba',
                    position='Winger',
                    number=7,
                    image_url='/static/images/kahraba.jpg'
                ),
                Player(
                    name='Rami Rabia',
                    position='Center Back',
                    number=5,
                    image_url='/static/images/rabia.jpg'
                ),
                Player(
                    name='Aliou Dieng',
                    position='Defensive Midfielder',
                    number=15,
                    image_url='/static/images/dieng.jpg'
                ),
                Player(
                    name='Ahmed Nabil Koka',
                    position='Midfielder',
                    number=19,
                    image_url='/static/images/koka.jpg'
                ),
                 Player(
                    name='Emam Ashour',
                    position='Midfielder',
                    number=22,
                    image_url='/static/images/ashour.jpg'
                ),
                Player(
                    name='Hamdi Fathi',
                    position='Defensive Midfielder',
                    number=6,
                    image_url='/static/images/fathi.jpg'
                ),
                Player(
                    name='Mohamed Magdy Afsha',
                    position='Attacking Midfielder',
                    number=19,
                    image_url='/static/images/afsha.jpg'
                ),
                Player(
                    name='Yasser Ibrahim',
                    position='Center Back',
                    number=6,
                    image_url='/static/images/yasser.jpg'
                ),
                Player(
                    name='Mostafa Shobeir',
                    position='Goalkeeper',
                    number=16,
                    image_url='/static/images/shobeir.jpg'
                ),
                Player(
                    name='Taher Mohamed',
                    position='Winger',
                    number=27,
                    image_url='/static/images/taher.jpg'
                ),
                Player(
                    name='Mohammed Hany',
                    position='Right Back',
                    number=30,
                    image_url='/static/images/hany.jpg'
                ),
                Player(
                    name='Karim Fouad',
                    position='Right Back',
                    number=13,
                    image_url='/static/images/fouad.jpg'
                ),
                  Player(
                    name=' omar kamal',
                    position='Right Back',
                    number=3,
                    image_url='/static/images/kamal.jpg'
                ),
            ]
            
            try:
                for player in sample_players:
                    db.session.add(player)
                db.session.commit()
            except Exception as e:
                db.session.rollback()
                print(f"Error initializing database: {e}")

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
